import cv2 as cv
import matplotlib as plt
import numpy as py
import Lib
import math


Gaussian=[[1,2,1],[2,4,2],[1,2,1]]
Sobelx=[[-1,0,1],[-2,0,2],[-1,0,1]]
Sobely=[[-1,-2,-1],[0,0,0],[1,2,1]]
Gaussian5=[[1,4,7,4,1],[4,16,26,16,4],[7,26,41,26,7],[4,16,26,16,4],[1,4,7,4,1]]
Filter=[[1,1,1],[1,1,1],[1,1,1]]
x=cv.imread('Pic2.png',0)
#Task1 Applying global mean??
Mean=py.mean(x); size=py.shape(x); median=py.median(x); t1=py.zeros((size[0],size[1]),dtype=py.uint64);t2=py.zeros((size[0],size[1]),dtype=py.uint64)
# for i in range(size[0]):
#     for j in range(size[1]):
#         if x[i][j]<Mean:
#             t1[i][j]=0
#         else:
#             t1[i][j]=255
# cv.imwrite('Task1.png',t1)
# for i in range(size[0]):
#     for j in range(size[1]):
#         if x[i][j]<median:
#             t2[i][j]=0
#         else:
#             t2[i][j]=255
# #task2 Applying mean 3x3 locally
# cv.imwrite('Task2.png',t2)


# Task2=Lib.Mean3x3(x,Filter)
# cv.imwrite('Task2Mean3x3.png',Task2)
y=Lib.RegionGrowing(x)
cv.imwrite('RegionGrowing.png',y)


