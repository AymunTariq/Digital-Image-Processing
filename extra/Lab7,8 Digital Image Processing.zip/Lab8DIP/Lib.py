import numpy
def ConvSum(Padded,Filter):
    SizeImage=numpy.shape(Padded)
    nr = SizeImage[0]
    nc = SizeImage[1]
    SizeFilter=numpy.shape(Filter)
    rows=SizeFilter[0]; cols=SizeFilter[1]
    Padded2=numpy.zeros((nr,nc),dtype=numpy.uint64)
    for i in range(nr):
        for j in range(nc):
            summ = 0
            for l in range(rows):
                for m in range(cols):
                    if i < (nr - 2) and j < (nc - 2):
                        summ = (Padded[i + l][j + m] * Filter[l][m]) + summ
            if i < nr or j < nc:
                Padded2[i][j] = summ

    return Padded2

def ConvSumx(Padded,Filter,Pad):
    SizeImage=numpy.shape(Padded)
    nr = SizeImage[0]
    nc = SizeImage[1]
    SizeFilter=numpy.shape(Filter)
    rows=SizeFilter[0]; cols=SizeFilter[1]
    Padded2=numpy.zeros((nr,nc),dtype=numpy.uint64)
    for i in range(nr):
        for j in range(nc):
            summ = 0
            for l in range(rows):
                for m in range(cols):
                    if i < (nr - (Pad*2)) and j < (nc - (Pad*2)):
                        summ = (Padded[i + l][j + m] * Filter[l][m]) + summ
                        # summ=summ/273
            if i < nr or j < nc:
                Padded2[i][j] = summ

    return Padded2


def Padding(Image):
    SizeImage=numpy.shape(Image)
    nr = SizeImage[0] + 2
    nc = SizeImage[1] + 2
    Padded = numpy.zeros((nr, nc), dtype=numpy.uint64)
    Padded2 = numpy.zeros((nr, nc), dtype=numpy.uint64)
    for i in range(nr):
        for j in range(nc):
            if i > 0 and i < nr - 1 and j > 0 and j < nc - 1:
                Padded[i][j] = Image[i - 1][j - 1]

    return Padded

def Paddingx(Image,Pad):
    SizeImage=numpy.shape(Image)
    nr = SizeImage[0] + Pad*2
    nc = SizeImage[1] + Pad*2
    Padded = numpy.zeros((nr, nc), dtype=numpy.uint64)
    Padded2 = numpy.zeros((nr, nc), dtype=numpy.uint64)
    for i in range(nr):
        for j in range(nc):
            if i >= Pad and i < nr - (Pad) and j >= Pad and j < nc - (Pad):
                Padded[i][j] = Image[i - Pad][j - Pad]

    return Padded

def testy(nums,target):
    for i in range(len(nums)):
        for j in range(1,len(nums)):

                if nums[i] + nums[j] == target and i!=j:
                    return i, j


def non_max_suppression(img, D):
    M, N = img.shape
    Z = numpy.zeros((M, N), dtype=numpy.int32)
    angle = D * 180. / numpy.pi
    angle[angle < 0] += 180

    for i in range(1, M - 1):
        for j in range(1, N - 1):
            try:
                q = 255
                r = 255

                # angle 0
                if (0 <= angle[i, j] < 22.5) or (157.5 <= angle[i, j] <= 180):
                    q = img[i, j + 1]
                    r = img[i, j - 1]
                # angle 45
                elif (22.5 <= angle[i, j] < 67.5):
                    q = img[i + 1, j - 1]
                    r = img[i - 1, j + 1]
                # angle 90
                elif (67.5 <= angle[i, j] < 112.5):
                    q = img[i + 1, j]
                    r = img[i - 1, j]
                # angle 135
                elif (112.5 <= angle[i, j] < 157.5):
                    q = img[i - 1, j - 1]
                    r = img[i + 1, j + 1]

                if (img[i, j] >= q) and (img[i, j] >= r):
                    Z[i, j] = img[i, j]
                else:
                    Z[i, j] = 0

            except IndexError as e:
                pass

    return Z

def Mean3x3(Padded,Filter):
    SizeImage=numpy.shape(Padded)
    nr = SizeImage[0]
    nc = SizeImage[1]
    SizeFilter=numpy.shape(Filter)
    rows=SizeFilter[0]; cols=SizeFilter[1]
    Padded2=numpy.zeros((nr,nc),dtype=numpy.uint64)
    for i in range(nr):
        for j in range(nc):
            summ = 0
            for l in range(rows):
                for m in range(cols):
                    if i < (nr - 2) and j < (nc - 2):
                        summ = (Padded[i + l][j + m] * Filter[l][m]) + summ
            if i < nr or j < nc:
                if (summ/9)<Padded[i][j]:
                     Padded2[i][j] =0;
                else:
                    Padded2[i][j]=255

    return Padded2

def findSeedPoint(Image):
    size = numpy.shape(Image)
    seedPoint = numpy.ceil(numpy.mean(Image))
    print(numpy.mean(Image))
    x=0;y=0
    for i in range(size[0]):
        for j in range(size[1]):
            if Image[i][j]==seedPoint:
                x=i;y=j
                break
    return x,y




#
def RegionGrowing(Image):
    size=numpy.shape(Image); Max=numpy.max(Image); Thresh= Max-100;Mat=numpy.zeros((size[0],size[1]),dtype=numpy.uint64)
    x=findSeedPoint(Image)
    for i in range(size[0]):
        for j in range(size[1]):
            if numpy.abs(Image[i][j]-Image[x[0]][x[1]])<Thresh:
                Mat[i][j]=255
            else:
                Mat[i][j]=0
    return Mat
