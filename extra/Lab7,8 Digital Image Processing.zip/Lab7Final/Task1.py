import cv2 as cv
import matplotlib as plt
import numpy as py
import Lib
import math


Gaussian=[[1,2,1],[2,4,2],[1,2,1]]
Sobelx=[[-1,0,1],[-2,0,2],[-1,0,1]]
Sobely=[[-1,-2,-1],[0,0,0],[1,2,1]]
Gaussian5=[[1,4,7,4,1],[4,16,26,16,4],[7,26,41,26,7],[4,16,26,16,4],[1,4,7,4,1]]

x=cv.imread('dc.png',0)
# CoinPad=Lib.Padding(x)
# Size=py.shape(CoinPad)
# Avg=Lib.ConvSum(CoinPad,Gaussian)
# Avg=Avg/16
# SobelX=Lib.ConvSum(Avg,Sobelx)
# SobelY=Lib.ConvSum(Avg,Sobely)
# Mag=py.multiply(SobelX,SobelX)+py.multiply(SobelY,SobelY)
#
# for i in range (Size[0]):
#     for j in range(Size[1]):
#             Mag[i][j]=((Mag[i][j] - py.min(Mag))/(py.max(Mag)-py.min(Mag)))*255
# cv.imwrite('Mag1.png',Mag)
# Mag=py.sqrt(Mag)
# MaxGray=py.max(Mag); MaxThresh=MaxGray-(MaxGray*.70)
# print(MaxGray);print(MaxThresh)
# for i in range (Size[0]):
#     for j in range(Size[1]):
#             if Mag[i][j]<MaxThresh:
#                 Mag[i][j]=0
#             elif Mag[i][j]>MaxThresh:
#                 Mag[i][j]=255
# cv.imwrite('Mag2.png',Mag)
# #Finding phase
# Phase=py.zeros((Size[0],Size[1]),dtype=py.float64)
# for i in range (Size[0]):
#     for j in range(Size[1]):
#             Phase[i][j]=math.atan(SobelY[i][j]/SobelX[i][j])
#             if (Phase[i][j]>1.570 and Phase[i][j]<1.572) or (Phase[i][j]>.7853 and Phase[i][j]<.7856):
#                 Phase[i][j]=255
# cv.imwrite('Phase.png',Phase)

CoinPad2=Lib.Paddingx(x,2)
CoinPad2=Lib.ConvSumx(CoinPad2,Gaussian5,2)
CoinPad2=CoinPad2/273
cv.imwrite('NoiseByGaussian.png',CoinPad2)
#Applying Sobel x and y
SobelX=Lib.ConvSum(CoinPad2,Sobelx)
SobelY=Lib.ConvSum(CoinPad2,Sobely)
Mag=py.multiply(SobelX,SobelX)+py.multiply(SobelY,SobelY)
Size=py.shape(CoinPad2)
Phase=py.zeros((Size[0],Size[1]),dtype=py.float64)
for i in range (Size[0]):
    for j in range(Size[1]):
            Phase[i][j]=math.atan(SobelY[i][j]/SobelX[i][j])
B=Lib.non_max_suppression(Mag,Phase)
cv.imwrite('b.png',B)
#Hysteresis Thresholding
Low=10;High=150
CannyFinal=py.zeros((Size[0],Size[1]),dtype=py.uint64)
for i in range (1,Size[0]):
    for j in range(1,Size[1]):
         if B[i][j]<50 and i < Size[0]-2 and j <Size[1]-2:
             if ((B[i + 1][ j - 1] > High) or (B[i + 1, j] > High) or (B[i + 1, j + 1] > High)
                 or (B[i, j - 1] > High) or (B[i, j + 1] > High)
                 or (B[i - 1, j - 1] > High) or (B[i - 1, j] > High) or (B[i - 1, j + 1] > High)):
                    CannyFinal[i][j]=High

cv.imwrite('CannyFinal.png',CannyFinal)
lines = cv.HoughLines(CannyFinal,1,py.pi/180,200)
cv.imwrite('Hough.png',lines)
